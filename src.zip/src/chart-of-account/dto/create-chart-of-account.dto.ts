export class CreateChartOfAccountDto {}
