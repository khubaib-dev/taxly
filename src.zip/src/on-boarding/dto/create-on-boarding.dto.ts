export class CreateOnBoardingDto {}
