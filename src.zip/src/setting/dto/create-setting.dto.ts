export class CreateSettingDto {}
