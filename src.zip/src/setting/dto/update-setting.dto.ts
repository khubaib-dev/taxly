export class UpdateSettingDto {
    tax_reminder?: string
    notification_type?: string
    work_status?: string
    travel_type?: string
    work_type?: string
    business_meal?: string
    f1?: string
    f2?: string
    f3?: string
}
