export class CreateCriterionDto {}
