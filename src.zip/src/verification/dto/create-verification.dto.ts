export class CreateVerificationDto {}
