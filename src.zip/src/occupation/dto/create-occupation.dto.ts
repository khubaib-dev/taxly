export class CreateOccupationDto {}
