export class CreateAichatDto {}
