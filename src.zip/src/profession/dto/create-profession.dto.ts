export class CreateProfessionDto {}
